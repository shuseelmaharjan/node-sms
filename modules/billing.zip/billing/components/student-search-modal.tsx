"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Search, UserRoundSearch } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Spinner } from "@/components/ui/spinner";

import { billingApi } from "../api/billing.api";
import type { StudentSearchResult } from "../types/billing.types";

export function StudentSearchModal(props: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const router = useRouter();
  const [search, setSearch] = React.useState("");
  const [batchId, setBatchId] = React.useState("");
  const [classId, setClassId] = React.useState("");
  const [sectionId, setSectionId] = React.useState("all");
  const [results, setResults] = React.useState<StudentSearchResult[]>([]);
  const [searched, setSearched] = React.useState(false);
  const [isSearching, setIsSearching] = React.useState(false);

  const batchesQuery = useQuery({
    queryKey: ["billing", "student-search", "batches"],
    queryFn: billingApi.listBatches,
    enabled: props.open,
  });

  const classesQuery = useQuery({
    queryKey: ["billing", "student-search", "classes", batchId],
    queryFn: () => billingApi.listClasses(Number(batchId)),
    enabled: props.open && Boolean(batchId),
  });

  const sectionsQuery = useQuery({
    queryKey: ["billing", "student-search", "sections", classId],
    queryFn: () => billingApi.listSections(classId),
    enabled: props.open && Boolean(classId),
  });

  React.useEffect(() => {
    setClassId("");
    setSectionId("all");
    setResults([]);
    setSearched(false);
  }, [batchId]);

  React.useEffect(() => {
    setSectionId("all");
    setResults([]);
    setSearched(false);
  }, [classId]);

  React.useEffect(() => {
    if (!props.open) {
      setSearch("");
      setBatchId("");
      setClassId("");
      setSectionId("all");
      setResults([]);
      setSearched(false);
      setIsSearching(false);
    }
  }, [props.open]);

  async function handleSearch() {
    const normalizedSearch = search.trim();

    if (normalizedSearch.length < 2) {
      toast.error("Enter at least 2 characters of the student's name or username.");
      return;
    }
    if (!batchId) {
      toast.error("Select a batch.");
      return;
    }
    if (!classId) {
      toast.error("Select a class.");
      return;
    }

    setIsSearching(true);
    try {
      const found = await billingApi.searchStudents({
        search: normalizedSearch,
        batchId: Number(batchId),
        academicClassId: classId,
        sectionId: sectionId === "all" ? undefined : sectionId,
      });

      setResults(found);
      setSearched(true);

      if (found.length === 1) {
        props.onOpenChange(false);
        router.push(`/students/${found[0].id}`);
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Student search failed.");
    } finally {
      setIsSearching(false);
    }
  }

  function openStudent(student: StudentSearchResult) {
    props.onOpenChange(false);
    router.push(`/students/${student.id}`);
  }

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Find student account</DialogTitle>
          <DialogDescription>
            Search an actively enrolled student by name or username, then open the student billing account.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-2 sm:grid-cols-2">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="billing-student-search">Name or username</Label>
            <Input
              id="billing-student-search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="e.g. Aarav or aarav.malla"
              autoComplete="off"
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  event.preventDefault();
                  void handleSearch();
                }
              }}
            />
          </div>

          <div className="space-y-2">
            <Label>Batch *</Label>
            <Select value={batchId} onValueChange={setBatchId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select batch" />
              </SelectTrigger>
              <SelectContent>
                {(batchesQuery.data ?? []).map((batch) => (
                  <SelectItem key={batch.id} value={String(batch.id)}>
                    {batch.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Class *</Label>
            <Select value={classId} onValueChange={setClassId} disabled={!batchId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder={batchId ? "Select class" : "Select batch first"} />
              </SelectTrigger>
              <SelectContent>
                {(classesQuery.data ?? []).map((classroom) => (
                  <SelectItem key={classroom.id} value={classroom.id}>
                    {classroom.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2 sm:col-span-2">
            <Label>Section (optional)</Label>
            <Select value={sectionId} onValueChange={setSectionId} disabled={!classId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="All sections" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All sections / no section</SelectItem>
                {(sectionsQuery.data ?? []).map((section) => (
                  <SelectItem key={section.id} value={section.id}>
                    {section.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {searched ? (
          <div className="rounded-xl border">
            {results.length ? (
              <div className="divide-y">
                {results.map((student) => (
                  <button
                    key={student.id}
                    type="button"
                    className="flex w-full items-center justify-between gap-4 p-4 text-left transition hover:bg-muted/50"
                    onClick={() => openStudent(student)}
                  >
                    <div className="min-w-0">
                      <div className="truncate font-medium">{student.full_name || "Student"}</div>
                      <div className="truncate text-sm text-muted-foreground">
                        @{student.username || "no-username"} · {student.current_enrollment?.batch_name || "—"} · {student.current_enrollment?.class_name || "—"}
                        {student.current_enrollment?.section_name
                          ? ` / ${student.current_enrollment.section_name}`
                          : ""}
                      </div>
                    </div>
                    <UserRoundSearch className="h-4 w-4 shrink-0 text-muted-foreground" />
                  </button>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-sm text-muted-foreground">
                No actively enrolled student matched the selected scope.
              </div>
            )}
          </div>
        ) : null}

        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => props.onOpenChange(false)} disabled={isSearching}>
            Cancel
          </Button>
          <Button type="button" onClick={() => void handleSearch()} disabled={isSearching}>
            {isSearching ? <Spinner className="mr-2" /> : <Search className="mr-2 h-4 w-4" />}
            {isSearching ? "Searching…" : "Search student"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
