import axios from "axios";

import { api, getApiErrorMessage } from "@/api";
import type { PaginatedResponse } from "@/types/api";
import type {
  BatchEntity,
  ClassroomEntity,
  SectionEntity,
} from "@/modules/academics/types/classroom.types";

import type {
  BillingRecord,
  StudentSearchResult,
} from "../types/billing.types";

const PAYMENTS_URL = "/api/v1/fees/fee-payments/";
const STUDENTS_URL = "/api/v1/students-360/";
const BATCHES_URL = "/api/v1/batches/";
const CLASSES_URL = "/api/v1/academics/classrooms/";
const SECTIONS_URL = "/api/v1/academics/sections/";

function normalizeError(error: unknown, operation: string): Error {
  if (!axios.isAxiosError(error)) {
    return error instanceof Error ? error : new Error(`${operation} failed.`);
  }

  if (!error.response) {
    return new Error(
      `${operation} failed because the backend did not return a response.`
    );
  }

  return new Error(getApiErrorMessage(error) || `${operation} failed.`);
}

function fileNameFromDisposition(
  disposition: string | undefined,
  fallback: string
): string {
  const utf8Match = disposition?.match(/filename\*=UTF-8''([^;]+)/i);
  if (utf8Match?.[1]) {
    try {
      return decodeURIComponent(utf8Match[1]);
    } catch {
      return utf8Match[1];
    }
  }

  const plainMatch = disposition?.match(/filename="?([^";]+)"?/i);
  return plainMatch?.[1] ?? fallback;
}

function saveBlob(blob: Blob, fileName: string): void {
  const blobUrl = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = blobUrl;
  anchor.download = fileName;
  anchor.style.display = "none";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
}

export type BillingListParams = {
  page?: number;
  page_size?: number;
  search?: string;
  ordering?: string;
  student_id?: string;
  enrollment_id?: string;
  status?: string;
  from_date?: string;
  to_date?: string;
};

export type SearchStudentsParams = {
  search: string;
  batchId: number;
  academicClassId: string;
  sectionId?: string;
};

export const billingApi = {
  list: async (
    params: BillingListParams
  ): Promise<PaginatedResponse<BillingRecord>> => {
    try {
      const response = await api.get<PaginatedResponse<BillingRecord>>(
        PAYMENTS_URL,
        { params }
      );
      return response.data;
    } catch (error) {
      throw normalizeError(error, "Loading billing records");
    }
  },

  downloadReceipt: async (record: BillingRecord): Promise<void> => {
    try {
      const response = await api.get<Blob>(
        `${PAYMENTS_URL}${encodeURIComponent(record.id)}/receipt-pdf/`,
        { responseType: "blob" }
      );

      saveBlob(
        response.data,
        fileNameFromDisposition(
          response.headers?.["content-disposition"],
          `${record.receipt_number}.pdf`
        )
      );
    } catch (error) {
      throw normalizeError(error, "Receipt PDF download");
    }
  },

  listBatches: async (): Promise<BatchEntity[]> => {
    const response = await api.get<PaginatedResponse<BatchEntity>>(
      BATCHES_URL,
      { params: { status: "active", page_size: 200 } }
    );
    return response.data.results ?? [];
  },

  listClasses: async (batchId: number): Promise<ClassroomEntity[]> => {
    const response = await api.get<PaginatedResponse<ClassroomEntity>>(
      CLASSES_URL,
      { params: { batch_id: batchId, batch: batchId, page_size: 200 } }
    );
    return response.data.results ?? [];
  },

  listSections: async (academicClassId: string): Promise<SectionEntity[]> => {
    const response = await api.get<PaginatedResponse<SectionEntity>>(
      SECTIONS_URL,
      { params: { academic_class_id: academicClassId, page_size: 200 } }
    );
    return response.data.results ?? [];
  },

  searchStudents: async ({
    search,
    batchId,
    academicClassId,
    sectionId,
  }: SearchStudentsParams): Promise<StudentSearchResult[]> => {
    try {
      const response = await api.get<PaginatedResponse<StudentSearchResult>>(
        STUDENTS_URL,
        {
          params: {
            search: search.trim(),
            enrollment_status: "enrolled",
            batch: batchId,
            academic_class: academicClassId,
            section: sectionId || undefined,
            page_size: 100,
          },
        }
      );

      // Defensive client filtering protects navigation when older backends
      // ignore academic_class/section query parameters.
      return (response.data.results ?? []).filter((student) => {
        const enrollment = student.current_enrollment;
        if (!enrollment) return false;
        if (enrollment.batch_id !== batchId) return false;
        if (enrollment.academic_class_id !== academicClassId) return false;
        if (sectionId && enrollment.section_id !== sectionId) return false;
        return true;
      });
    } catch (error) {
      throw normalizeError(error, "Searching students");
    }
  },
};
